#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# FASE 04: Containerd
# SystemdCgroup = true es crítico: sin él kubelet y containerd
# usan gestores de cgroup distintos → pods en NotReady indefinido.
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

echo "[04-containerd] Iniciando..."

# CORRECCIÓN: excluir el kernel del update para no invalidar
# los módulos cargados en la fase 02 durante este mismo arranque
dnf update -y --exclude=kernel*
echo "[04-containerd] Sistema actualizado (kernel excluido)"

# aws-cli ya viene preinstalado en Amazon Linux 2023,
# pero lo incluimos para garantizar la versión más reciente
dnf install -y containerd
echo "[04-containerd] containerd instalado"

systemctl enable --now containerd
echo "[04-containerd] containerd habilitado e iniciado"

# Generar config base y activar SystemdCgroup
containerd config default > /etc/containerd/config.toml
echo "[04-containerd] config.toml generado"

sed -i 's/SystemdCgroup = false/SystemdCgroup = true/g' /etc/containerd/config.toml

# Verificar el cambio antes de reiniciar
if ! grep -q "SystemdCgroup = true" /etc/containerd/config.toml; then
  echo "[04-containerd] ERROR: SystemdCgroup no se actualizó"
  echo "[04-containerd] Contenido relevante del config.toml:"
  grep -A2 -B2 "SystemdCgroup" /etc/containerd/config.toml || true
  exit 1
fi
echo "[04-containerd] SystemdCgroup = true verificado en config.toml"

systemctl restart containerd
echo "[04-containerd] containerd reiniciado"

# Verificar que el servicio quedó activo
if ! systemctl is-active --quiet containerd; then
  echo "[04-containerd] ERROR: containerd no está activo tras reinicio"
  systemctl status containerd --no-pager || true
  exit 1
fi
echo "[04-containerd] containerd activo: OK"

# Verificar que el socket está disponible (lo necesita kubelet)
SOCKET="/run/containerd/containerd.sock"
for i in $(seq 1 10); do
  if [ -S "$SOCKET" ]; then
    echo "[04-containerd] Socket $SOCKET disponible: OK"
    break
  fi
  if [ "$i" -eq 10 ]; then
    echo "[04-containerd] ERROR: socket $SOCKET no disponible tras 10s"
    exit 1
  fi
  echo "[04-containerd] Esperando socket... intento $i/10"
  sleep 1
done

echo "[04-containerd] OK"
