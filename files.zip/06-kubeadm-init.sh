#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# FASE 06 (Control Plane): kubeadm init
# IP privada para anuncio interno, IP pública en SAN del certificado.
# Publica join command en SSM solo cuando el nodo está Ready.
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

POD_CIDR="${pod_network_cidr}"
ENV_PREFIX="${env_prefix}"
REGION="${aws_region}"

echo "[06-kubeadm-init] Iniciando..."

# Obtener IPs del metadata service de AWS
PRIVATE_IP=$(curl -sf http://169.254.169.254/latest/meta-data/local-ipv4)
PUBLIC_IP=$(curl -sf http://169.254.169.254/latest/meta-data/public-ipv4)

if [ -z "$PRIVATE_IP" ] || [ -z "$PUBLIC_IP" ]; then
  echo "[06-kubeadm-init] ERROR: no se pudieron obtener las IPs del metadata service"
  exit 1
fi
echo "[06-kubeadm-init] IP privada: $PRIVATE_IP | IP pública: $PUBLIC_IP"

# CORRECCIÓN: polling activo al socket de containerd
# en lugar del sleep 20 ciego
echo "[06-kubeadm-init] Esperando socket de containerd..."
SOCKET="/run/containerd/containerd.sock"
for i in $(seq 1 30); do
  if [ -S "$SOCKET" ] && systemctl is-active --quiet containerd; then
    echo "[06-kubeadm-init] containerd listo (intento $i)"
    break
  fi
  if [ "$i" -eq 30 ]; then
    echo "[06-kubeadm-init] ERROR: containerd no disponible tras 30 intentos"
    systemctl status containerd --no-pager || true
    exit 1
  fi
  echo "[06-kubeadm-init] containerd no listo aún, esperando 5s... ($i/30)"
  sleep 5
done

echo "[06-kubeadm-init] Ejecutando kubeadm init..."
kubeadm init \
  --pod-network-cidr="$POD_CIDR" \
  --apiserver-advertise-address="$PRIVATE_IP" \
  --apiserver-cert-extra-sans="$PUBLIC_IP" \
  --node-name="$(hostname -s)"
echo "[06-kubeadm-init] kubeadm init completado"

# Configurar kubectl para ec2-user
mkdir -p /home/ec2-user/.kube
cp /etc/kubernetes/admin.conf /home/ec2-user/.kube/config
chown -R ec2-user:ec2-user /home/ec2-user/.kube
echo "[06-kubeadm-init] kubectl configurado para ec2-user"

export KUBECONFIG=/etc/kubernetes/admin.conf

# Instalar Flannel CNI
echo "[06-kubeadm-init] Instalando Flannel CNI..."
kubectl apply -f \
  https://raw.githubusercontent.com/flannel-io/flannel/master/Documentation/kube-flannel.yml
echo "[06-kubeadm-init] Flannel aplicado"

# CORRECCIÓN: loop con exit 1 explícito si se agotan los intentos
echo "[06-kubeadm-init] Esperando a que el nodo esté Ready..."
NODE_NAME="$(hostname -s)"
READY=false
for i in $(seq 1 24); do
  STATUS=$(kubectl get node "$NODE_NAME" \
    --no-headers \
    -o custom-columns="STATUS:.status.conditions[-1].type" 2>/dev/null \
    || echo "Desconocido")

  if [ "$STATUS" = "Ready" ]; then
    echo "[06-kubeadm-init] Nodo $NODE_NAME en estado Ready (intento $i)"
    READY=true
    break
  fi

  echo "[06-kubeadm-init] Intento $i/24: estado='$STATUS', esperando 15s..."
  sleep 15
done

if [ "$READY" != "true" ]; then
  echo "[06-kubeadm-init] ERROR: nodo no alcanzó Ready tras 6 minutos"
  kubectl get nodes -o wide || true
  kubectl describe node "$NODE_NAME" || true
  exit 1
fi

# Publicar join command en SSM
echo "[06-kubeadm-init] Generando y publicando join command en SSM..."
JOIN_CMD=$(kubeadm token create --print-join-command)

aws ssm put-parameter \
  --name "/$ENV_PREFIX/join-command" \
  --value "$JOIN_CMD" \
  --type "SecureString" \
  --overwrite \
  --region "$REGION"
echo "[06-kubeadm-init] join-command publicado"

aws ssm put-parameter \
  --name "/$ENV_PREFIX/control-plane-ready" \
  --value "true" \
  --type "String" \
  --overwrite \
  --region "$REGION"
echo "[06-kubeadm-init] Señal control-plane-ready publicada"

echo "[06-kubeadm-init] OK"
