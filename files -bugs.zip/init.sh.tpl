#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# ORQUESTADOR: init.sh
# Ejecuta cada fase en orden. Si una falla, para inmediatamente
# e indica exactamente qué fase falló y en qué nodo.
# Cada fase escribe en su propio log Y en el log global.
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

NODE_ROLE="${node_role}"   # "control-plane" o "worker"
LOG_DIR="/var/log/k8s-init"
GLOBAL_LOG="$LOG_DIR/init.log"

mkdir -p "$LOG_DIR"
exec > >(tee -a "$GLOBAL_LOG") 2>&1

echo "======================================================"
echo "INICIO: $(date)"
echo "Nodo: $(hostname -s) | Rol: $NODE_ROLE"
echo "======================================================"

# ── Función central de ejecución por fase ─────────────────────────
run_phase() {
  local PHASE_NAME="$1"
  local SCRIPT_PATH="$2"
  local PHASE_LOG="$LOG_DIR/$PHASE_NAME.log"

  echo ""
  echo ">>> FASE: $PHASE_NAME — $(date)"

  # Ejecutar el script redirigiendo también a su log individual
  if bash "$SCRIPT_PATH" 2>&1 | tee "$PHASE_LOG"; then
    echo "<<< FASE: $PHASE_NAME — COMPLETADA OK"
  else
    echo "<<< FASE: $PHASE_NAME — FALLIDA ❌"
    echo ""
    echo "Para ver el detalle del error:"
    echo "  cat $PHASE_LOG"
    echo ""
    echo "Para ver todos los logs:"
    echo "  ls $LOG_DIR"
    exit 1
  fi
}

# ── Escribir scripts al disco desde variables de entorno ──────────
# templatefile() inyecta el contenido de cada script como variable
# El orquestador los reconstruye en disco y los ejecuta

SCRIPT_DIR="/opt/k8s-scripts"
mkdir -p "$SCRIPT_DIR/common" "$SCRIPT_DIR/$NODE_ROLE"

# Escribir fases comunes
cat <<'SCRIPT' > "$SCRIPT_DIR/common/01-swap.sh"
${script_01_swap}
SCRIPT

cat <<'SCRIPT' > "$SCRIPT_DIR/common/02-kernel-modules.sh"
${script_02_modules}
SCRIPT

cat <<'SCRIPT' > "$SCRIPT_DIR/common/03-sysctl.sh"
${script_03_sysctl}
SCRIPT

cat <<'SCRIPT' > "$SCRIPT_DIR/common/04-containerd.sh"
${script_04_containerd}
SCRIPT

cat <<'SCRIPT' > "$SCRIPT_DIR/common/05-kubernetes.sh"
${script_05_kubernetes}
SCRIPT

# Escribir fase específica del rol
cat <<'SCRIPT' > "$SCRIPT_DIR/$NODE_ROLE/06-role.sh"
${script_06_role}
SCRIPT

chmod +x "$SCRIPT_DIR/common/"*.sh "$SCRIPT_DIR/$NODE_ROLE/06-role.sh"

# ── Ejecutar fases en orden ────────────────────────────────────────
run_phase "01-swap"           "$SCRIPT_DIR/common/01-swap.sh"
run_phase "02-kernel-modules" "$SCRIPT_DIR/common/02-kernel-modules.sh"
run_phase "03-sysctl"         "$SCRIPT_DIR/common/03-sysctl.sh"
run_phase "04-containerd"     "$SCRIPT_DIR/common/04-containerd.sh"
run_phase "05-kubernetes"     "$SCRIPT_DIR/common/05-kubernetes.sh"
run_phase "06-$NODE_ROLE"     "$SCRIPT_DIR/$NODE_ROLE/06-role.sh"

echo ""
echo "======================================================"
echo "COMPLETADO: $(date)"
echo "Nodo: $(hostname -s) — todas las fases OK"
echo "Logs individuales en: $LOG_DIR/"
echo "======================================================"
