#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# FASE 05: Binarios de Kubernetes
# Instala kubelet, kubeadm y kubectl desde el repositorio oficial.
# kubelet se habilita pero NO se inicia — kubeadm lo arranca
# en el momento correcto durante init o join.
# K8S_VERSION se inyecta por templatefile() desde Terraform.
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

K8S_VERSION="${k8s_version}"

echo "[05-kubernetes] Iniciando con versión $K8S_VERSION..."

cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://pkgs.k8s.io/core:/stable:/$K8S_VERSION/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/$K8S_VERSION/rpm/repodata/repomd.xml.key
EOF
echo "[05-kubernetes] Repositorio configurado para $K8S_VERSION"

dnf install -y kubelet kubeadm kubectl
echo "[05-kubernetes] kubelet, kubeadm y kubectl instalados"

systemctl enable kubelet
echo "[05-kubernetes] kubelet habilitado (kubeadm lo iniciará en su momento)"

# Verificar que los binarios están disponibles
for bin in kubelet kubeadm kubectl; do
  command -v $bin || {
    echo "[05-kubernetes] ERROR: $bin no encontrado en PATH"
    exit 1
  }
  echo "[05-kubernetes] $bin disponible: $(command -v $bin)"
done

echo "[05-kubernetes] OK"
