#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# FASE 06 (Control Plane): kubeadm init
# - Usa IP privada para el anuncio interno entre nodos
# - Añade IP pública al certificado SAN para kubectl remoto
# - Instala Flannel como CNI
# - Publica el join command en SSM para los workers
# Variables inyectadas por templatefile(): pod_network_cidr,
# env_prefix, aws_region
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

POD_CIDR="${pod_network_cidr}"
ENV_PREFIX="${env_prefix}"
REGION="${aws_region}"

echo "[06-kubeadm-init] Iniciando..."

# Obtener IPs desde el metadata service de AWS
PRIVATE_IP=$(curl -s http://169.254.169.254/latest/meta-data/local-ipv4)
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)
echo "[06-kubeadm-init] IP privada: $PRIVATE_IP | IP pública: $PUBLIC_IP"

# Esperar a que containerd y kubelet estén estables
echo "[06-kubeadm-init] Esperando 20s para que los servicios estabilicen..."
sleep 20

# Inicializar el clúster
# --apiserver-advertise-address usa la IP PRIVADA para comunicación interna
# --apiserver-cert-extra-sans añade la IP PÚBLICA al certificado TLS
# para que kubectl desde tu máquina local pueda conectar
echo "[06-kubeadm-init] Ejecutando kubeadm init..."
kubeadm init \
  --pod-network-cidr="$POD_CIDR" \
  --apiserver-advertise-address="$PRIVATE_IP" \
  --apiserver-cert-extra-sans="$PUBLIC_IP" \
  --node-name="$(hostname -s)"

echo "[06-kubeadm-init] kubeadm init completado"

# Configurar kubectl para ec2-user
mkdir -p /home/ec2-user/.kube
cp /etc/kubernetes/admin.conf /home/ec2-user/.kube/config
chown -R ec2-user:ec2-user /home/ec2-user/.kube
echo "[06-kubeadm-init] kubectl configurado para ec2-user"

export KUBECONFIG=/etc/kubernetes/admin.conf

# Instalar Flannel como CNI (red de pods)
echo "[06-kubeadm-init] Instalando Flannel CNI..."
kubectl apply -f https://raw.githubusercontent.com/flannel-io/flannel/master/Documentation/kube-flannel.yml
echo "[06-kubeadm-init] Flannel instalado"

# Esperar a que el nodo control-plane esté Ready antes de publicar el join
echo "[06-kubeadm-init] Esperando a que el nodo esté Ready..."
for i in $(seq 1 20); do
  STATUS=$(kubectl get node "$(hostname -s)" \
    --no-headers \
    -o custom-columns="STATUS:.status.conditions[-1].type" 2>/dev/null || echo "NotReady")

  if [ "$STATUS" = "Ready" ]; then
    echo "[06-kubeadm-init] Nodo en estado Ready"
    break
  fi
  echo "[06-kubeadm-init] Intento $i/20: estado=$STATUS, esperando 15s..."
  sleep 15
done

# Publicar join command en SSM para los workers
echo "[06-kubeadm-init] Publicando join command en SSM..."
JOIN_CMD=$(kubeadm token create --print-join-command)

aws ssm put-parameter \
  --name "/$ENV_PREFIX/join-command" \
  --value "$JOIN_CMD" \
  --type "SecureString" \
  --overwrite \
  --region "$REGION"
echo "[06-kubeadm-init] join-command publicado en SSM"

# Señal de readiness para los workers
aws ssm put-parameter \
  --name "/$ENV_PREFIX/control-plane-ready" \
  --value "true" \
  --type "String" \
  --overwrite \
  --region "$REGION"
echo "[06-kubeadm-init] Señal control-plane-ready publicada en SSM"

echo "[06-kubeadm-init] OK"
