#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# FASE 01: Desactivar swap
# K8s requiere swap desactivado. Si está activo, kubeadm falla
# con un error explícito y no continúa.
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

echo "[01-swap] Iniciando..."

swapoff -a
echo "[01-swap] Swap desactivado en memoria"

sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab
echo "[01-swap] Swap comentado en /etc/fstab (persistente tras reinicio)"

echo "[01-swap] OK"
