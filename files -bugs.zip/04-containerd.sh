#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# FASE 04: Containerd
# Runtime de contenedores que usa Kubernetes.
# El cambio crítico es SystemdCgroup = true: sin él, kubelet y
# containerd usan gestores de cgroup distintos y los pods quedan
# en NotReady sin mensaje de error obvio.
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

echo "[04-containerd] Iniciando..."

dnf update -y
echo "[04-containerd] Sistema actualizado"

dnf install -y containerd aws-cli
echo "[04-containerd] containerd y aws-cli instalados"

systemctl enable --now containerd
echo "[04-containerd] containerd habilitado e iniciado"

# Generar configuración base y ajustar SystemdCgroup
containerd config default > /etc/containerd/config.toml
echo "[04-containerd] config.toml generado"

sed -i 's/SystemdCgroup = false/SystemdCgroup = true/g' /etc/containerd/config.toml
echo "[04-containerd] SystemdCgroup cambiado a true"

# Verificar que el cambio se aplicó
grep "SystemdCgroup = true" /etc/containerd/config.toml || {
  echo "[04-containerd] ERROR: SystemdCgroup no se actualizó en config.toml"
  exit 1
}

systemctl restart containerd
echo "[04-containerd] containerd reiniciado con nueva configuración"

# Verificar que el servicio está activo
systemctl is-active containerd || {
  echo "[04-containerd] ERROR: containerd no está activo tras reinicio"
  exit 1
}

echo "[04-containerd] OK"
