#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# FASE 02: Módulos de kernel
# overlay    → containerd necesita este módulo para gestionar
#              las capas del sistema de archivos de contenedores
# br_netfilter → permite que iptables inspeccione tráfico de bridges
#                sin esto las reglas de red de K8s no funcionan
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

echo "[02-kernel-modules] Iniciando..."

cat <<EOF > /etc/modules-load.d/k8s.conf
overlay
br_netfilter
EOF
echo "[02-kernel-modules] Archivo /etc/modules-load.d/k8s.conf creado"

modprobe overlay
echo "[02-kernel-modules] Módulo overlay cargado"

modprobe br_netfilter
echo "[02-kernel-modules] Módulo br_netfilter cargado"

# Verificar que los módulos están activos
lsmod | grep -E "^(overlay|br_netfilter)" || {
  echo "[02-kernel-modules] ERROR: módulos no encontrados tras carga"
  exit 1
}

echo "[02-kernel-modules] OK"
