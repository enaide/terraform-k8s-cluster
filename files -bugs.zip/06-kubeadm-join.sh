#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# FASE 06 (Worker): kubeadm join
# Hace polling a SSM esperando la señal del control-plane.
# Cuando la recibe, descarga el join command y lo ejecuta.
# Máximo de espera: 40 intentos × 30s = 20 minutos.
# Variables inyectadas por templatefile(): env_prefix, aws_region
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

ENV_PREFIX="${env_prefix}"
REGION="${aws_region}"

echo "[06-kubeadm-join] Iniciando en $(hostname -s)..."

# Polling: esperar señal del control-plane
echo "[06-kubeadm-join] Esperando señal del control-plane en SSM..."
for i in $(seq 1 40); do
  READY=$(aws ssm get-parameter \
    --name "/$ENV_PREFIX/control-plane-ready" \
    --region "$REGION" \
    --query "Parameter.Value" \
    --output text 2>/dev/null || echo "false")

  if [ "$READY" = "true" ]; then
    echo "[06-kubeadm-join] Control-plane listo. Procediendo."
    break
  fi

  if [ "$i" -eq 40 ]; then
    echo "[06-kubeadm-join] ERROR: timeout esperando al control-plane (20 min)"
    exit 1
  fi

  echo "[06-kubeadm-join] Intento $i/40: no listo. Esperando 30s..."
  sleep 30
done

# Obtener join command desde SSM
echo "[06-kubeadm-join] Descargando join command desde SSM..."
JOIN_CMD=$(aws ssm get-parameter \
  --name "/$ENV_PREFIX/join-command" \
  --with-decryption \
  --region "$REGION" \
  --query "Parameter.Value" \
  --output text)

echo "[06-kubeadm-join] join command obtenido"

# Ejecutar el join
echo "[06-kubeadm-join] Ejecutando kubeadm join..."
eval "$JOIN_CMD"

echo "[06-kubeadm-join] $(hostname -s) unido al clúster correctamente"
echo "[06-kubeadm-join] OK"
